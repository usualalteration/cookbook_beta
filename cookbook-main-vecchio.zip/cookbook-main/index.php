<!DOCTYPE html>
<html>
    <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
        <title>Ricettario di Nicoletta</title>
    </head>
    <body>
        <header>
            <h1>Ricettario di Nicoletta</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="ricette.php">Ricette</a></li>
                    <li><a href="inserisci.html">Aggiungi</a></li>
                    <li><a href="cerca.php">Cerca</a></li>
                    <li><a href="https://usualalteration.github.io/">Chi sono</a></li>
                </ul>
            </nav>
        </header>
    </body>
</html>